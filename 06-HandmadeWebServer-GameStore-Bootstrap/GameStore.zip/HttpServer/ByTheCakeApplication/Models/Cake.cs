﻿namespace HttpServer.ByTheCakeApplication.Models
{
    // TODO: Remove this when the DB is fully implemented
    public class Cake
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public decimal Price { get; set; }
    }
}

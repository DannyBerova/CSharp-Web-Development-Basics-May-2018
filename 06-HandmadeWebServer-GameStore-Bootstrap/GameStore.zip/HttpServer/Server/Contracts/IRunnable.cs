﻿namespace HttpServer.Server.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
﻿namespace SimpleMvc.Framework.Interfaces
{
    public interface IActionResult
    {   
        string Invoke();
    }
}

﻿namespace HttpServer.Server.Contracts
{
    public interface IView
    {
        string View();
    }
}

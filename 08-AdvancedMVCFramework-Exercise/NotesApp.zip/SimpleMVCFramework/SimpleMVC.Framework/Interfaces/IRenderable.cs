﻿namespace SimpleMVC.Framework.Interfaces
{
    public interface IRenderable
    {
        string Render();
    }
}

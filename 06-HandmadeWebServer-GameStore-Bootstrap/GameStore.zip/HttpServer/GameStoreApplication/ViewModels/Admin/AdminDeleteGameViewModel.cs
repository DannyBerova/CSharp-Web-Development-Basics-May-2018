﻿namespace HttpServer.GameStoreApplication.ViewModels.Admin
{
    public class AdminDeleteGameViewModel
    {
        public int GameId { get; set; }
    }
}

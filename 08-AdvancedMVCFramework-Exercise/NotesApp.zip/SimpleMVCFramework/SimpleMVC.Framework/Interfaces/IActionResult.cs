﻿namespace SimpleMVC.Framework.Interfaces
{
    public interface IActionResult
    {
        string Invoke();
    }
}

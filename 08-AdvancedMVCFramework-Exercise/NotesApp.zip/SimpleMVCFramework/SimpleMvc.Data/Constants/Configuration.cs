﻿namespace SimpleMvc.Data.Constants
{
    public class Configuration
    {
        public const string ConfigurationString =
            @"Server=.;Database=NotesDb;Integrated Security=True";
    }
}

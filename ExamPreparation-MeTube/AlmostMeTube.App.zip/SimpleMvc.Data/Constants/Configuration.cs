﻿namespace SimpleMvc.Data.Constants
{
    public class Configuration
    {
        public const string ConfigurationString =
            @"Server=DESKTOP-32FEOB6\SQLEXPRESS;Database=MeTubeDbDanny;Integrated Security=True";
    }
}
